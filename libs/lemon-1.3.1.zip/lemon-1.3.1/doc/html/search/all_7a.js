var searchData=
[
  ['zero',['zero',['../a00046.html#af24efe5c6b0edcb586538222fb5b1024',1,'lemon::BellmanFordDefaultOperationTraits::zero()'],['../a00134.html#af24efe5c6b0edcb586538222fb5b1024',1,'lemon::DijkstraDefaultOperationTraits::zero()'],['../a00426.html#af24efe5c6b0edcb586538222fb5b1024',1,'lemon::Tolerance::zero()'],['../a00428.html#af24efe5c6b0edcb586538222fb5b1024',1,'lemon::Tolerance&lt; float &gt;::zero()'],['../a00427.html#af24efe5c6b0edcb586538222fb5b1024',1,'lemon::Tolerance&lt; double &gt;::zero()'],['../a00429.html#af24efe5c6b0edcb586538222fb5b1024',1,'lemon::Tolerance&lt; long double &gt;::zero()']]]
];
