var searchData=
[
  ['time_20measuring_20and_20counting',['Time Measuring and Counting',['../a00626.html',1,'']]],
  ['traveling_20salesman_20problem',['Traveling Salesman Problem',['../a00618.html',1,'']]],
  ['tools_20and_20utilities',['Tools and Utilities',['../a00623.html',1,'']]]
];
