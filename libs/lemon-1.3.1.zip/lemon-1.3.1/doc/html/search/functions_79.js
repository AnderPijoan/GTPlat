var searchData=
[
  ['ymap',['YMap',['../a00440.html#ab5f6a5b671ba21e3dd3164a28c6d4d1f',1,'lemon::dim2::YMap::YMap(M &amp;map)'],['../a00606.html#ga4b8a44ffc54cb9a2db2517d2a17f18af',1,'lemon::dim2::YMap::yMap(M &amp;m)'],['../a00606.html#gacd6c062290503f0e72b7ff1e3ac82bcd',1,'lemon::dim2::ConstYMap::yMap()']]]
];
